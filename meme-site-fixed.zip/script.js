
console.log('Site loaded. Waiting for wallet connection...');
